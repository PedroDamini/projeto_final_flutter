package com.example.meuapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
