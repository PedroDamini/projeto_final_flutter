# meuapp

Projeto da disciplina Mobile 3.

## Getting Started

Para rodar o projeto basta cloná-lo
abrir com o editor
 rodar o comando "flutter pub get"

 depois

 flutter run.

 Correr pro abraço!
